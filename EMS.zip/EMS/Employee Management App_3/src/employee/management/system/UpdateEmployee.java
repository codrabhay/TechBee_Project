package employee.management.system;


import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;

public class UpdateEmployee extends JFrame implements ActionListener{
    
    JTextField tfeducation, tffname, tfaddress, tfphone, tfaadhar, tfemail, tfsalary, tfdesignation;
    JLabel lblempId;
    JButton add, back;
    String empId;
    
    UpdateEmployee(String empId) {
        this.empId = empId;
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);
        setTitle("HCL Employee Management System - Update Employee");
        ImageIcon favicon = new ImageIcon(ClassLoader.getSystemResource("icons/Hcl.jpg"));
        setIconImage(favicon.getImage());
        

        //Creating an object of JLabel class and setting the heading of the frame
        JLabel heading = new JLabel("Update Employee Detail");
        //Setting the bounds of the heading
        heading.setBounds(320, 30, 500, 50);
        //Setting the font of the heading
        heading.setFont(new Font("SAN_SERIF", Font.BOLD, 25));
        //Adding the heading to the frame
        add(heading);
        
        //Creating an object of JLabel class and setting the label
        JLabel labelname = new JLabel("Name");
        //Setting the bounds of the label
        labelname.setBounds(50, 150, 150, 30);
        //Setting the font of the label
        labelname.setFont(new Font("serif", Font.PLAIN, 20));
        //Adding the label to the frame
        add(labelname);
        
        //Creating an object of JLabel class
        JLabel lblname = new JLabel();
        //Setting the bounds of the label
        lblname.setBounds(200, 150, 150, 30);
        //Adding the label to the frame
        add(lblname);
        
        //Creating an object of JLabel class and setting the label
        JLabel labelfname = new JLabel("Father's Name");
        //Setting the bounds of the label
        labelfname.setBounds(400, 150, 150, 30);
        //Setting the font of the label
        labelfname.setFont(new Font("serif", Font.PLAIN, 20));
        //Adding the label to the frame
        add(labelfname);
        
        //Creating an object of JTextField class
        tffname = new JTextField();
        //Setting the bounds of the textfield
        tffname.setBounds(600, 150, 150, 30);
        //Adding the textfield to the frame
        add(tffname);
        
        
        //Creating a label to display the text "Employee ID" 
        JLabel labelid = new JLabel("Employee ID");
        //Setting the size and position of the label
        labelid.setBounds(50, 100, 150, 30);
        //Setting the font of the text to be displayed
        labelid.setFont(new Font("serif", Font.PLAIN, 20));
        //Adding the label to the JFrame
        add(labelid);
        
        //Creating a label to display the text "Date of Birth"
        JLabel labeldob = new JLabel("Date of Birth");
        //Setting the size and position of the label
        labeldob.setBounds(50, 200, 150, 30);
        //Setting the font of the text to be displayed
        labeldob.setFont(new Font("serif", Font.PLAIN, 20));
        //Adding the label to the JFrame
        add(labeldob);
        
        //Creating a label to display the text "Salary"
        JLabel labelsalary = new JLabel("Salary");
        //Setting the size and position of the label
        labelsalary.setBounds(400, 200, 150, 30);
        //Setting the font of the text to be displayed
        labelsalary.setFont(new Font("serif", Font.PLAIN, 20));
        //Adding the label to the JFrame
        add(labelsalary);
        
        //Creating a textfield to enter the salary value
        tfsalary = new JTextField();
        //Setting the size and position of the textfield
        tfsalary.setBounds(600, 200, 150, 30);
        //Adding the textfield to the JFrame
        add(tfsalary);
        
        //Creating a label to display the text "Address"
        JLabel labeladdress = new JLabel("Address");
        //Setting the size and position of the label
        labeladdress.setBounds(50, 250, 150, 30);
        //Setting the font of the text to be displayed
        labeladdress.setFont(new Font("serif", Font.PLAIN, 20));
        //Adding the label to the JFrame
        add(labeladdress);
        
        //Creating a textfield to enter the address value
        tfaddress = new JTextField();
        //Setting the size and position of the textfield
        tfaddress.setBounds(200, 250, 150, 30);
        //Adding the textfield to the JFrame
        add(tfaddress);
        
        //Creating a label to display the text "Phone"
        JLabel labelphone = new JLabel("Phone");
        //Setting the size and position of the label
        labelphone.setBounds(400, 250, 150, 30);
        //Setting the font of the text to be displayed
        labelphone.setFont(new Font("serif", Font.PLAIN, 20));
        //Adding the label to the JFrame
        add(labelphone);
        

      //Creating the Textfield for Phone
      tfphone = new JTextField();
      tfphone.setBounds(200, 250, 150, 30);
      add(tfphone);

      //Creating the label for Email
      JLabel labelemail = new JLabel("Email");
      labelemail.setBounds(50, 300, 150, 30);
      labelemail.setFont(new Font("serif", Font.PLAIN, 20));
      add(labelemail);

      //Creating the Textfield for Email
      tfemail = new JTextField();
      tfemail.setBounds(200, 300, 150, 30);
      add(tfemail);

      //Creating the label for Highest Education
      JLabel labeleducation = new JLabel("Higest Education");
      labeleducation.setBounds(400, 300, 150, 30);
      labeleducation.setFont(new Font("serif", Font.PLAIN, 20));
      add(labeleducation);

      //Creating the Textfield for Highest Education
      tfeducation = new JTextField();
      tfeducation.setBounds(600, 300, 150, 30);
      add(tfeducation);

      //Creating the label for Designation
      JLabel labeldesignation = new JLabel("Designation");
      labeldesignation.setBounds(50, 350, 150, 30);
      labeldesignation.setFont(new Font("serif", Font.PLAIN, 20));
      add(labeldesignation);

      //Creating the Textfield for Designation
      tfdesignation = new JTextField();
      tfdesignation.setBounds(200, 350, 150, 30);
      add(tfdesignation);

      //Creating the label for Aadhar Number
      JLabel labelaadhar = new JLabel("Aadhar Number");
      labelaadhar.setBounds(400, 350, 150, 30);
      labelaadhar.setFont(new Font("serif", Font.PLAIN, 20));
      add(labelaadhar);

      //Creating the label for Aadhar Number
      JLabel lblaadhar = new JLabel();
      lblaadhar.setBounds(600, 350, 150, 30);
      add(lblaadhar);

      //Creating the label for Employee Id
      JLabel labelempId = new JLabel("Employee id");
      labelempId.setBounds(50, 400, 150, 30);
      labelempId.setFont(new Font("serif", Font.PLAIN, 20));
      add(labelempId);

      //Creating the label for Employee Id
      lblempId = new JLabel();
      lblempId.setBounds(200, 400, 150, 30);
      lblempId.setFont(new Font("serif", Font.PLAIN, 20));
      add(lblempId);
        
        try {

        	 //Creating a connection
        	 Conn c = new Conn();
        	 
        	 //Creating a query to select all details from employee table
        	 String query = "select * from employee where empId = '"+empId+"'";
        	 
        	 //Executing the query and storing the result in ResultSet
        	 ResultSet rs = c.s.executeQuery(query);
        	 
        	 //Iterating through the ResultSet
        	 while(rs.next()) {
        	 	
        	 	//Setting the text of each label with respective value from the ResultSet
        		lblname.setText(rs.getString("name"));
        	    tffname.setText(rs.getString("fname"));
        	    labeldob.setText(rs.getString("dob"));
        	    tfaddress.setText(rs.getString("address"));
        	    tfsalary.setText(rs.getString("salary"));
        	    tfphone.setText(rs.getString("phone"));
        	    tfemail.setText(rs.getString("email"));
        	    tfeducation.setText(rs.getString("education"));
        	    lblaadhar.setText(rs.getString("aadhar"));
        	    lblempId.setText(rs.getString("empId"));
        	    tfdesignation.setText(rs.getString("designation"));
        	 }
        }
        	 //Catching any exception
        	 catch (Exception e) {
        	    e.printStackTrace();
        	 }        
        add = new JButton("Update Details");
        add.setBounds(250, 550, 150, 40);
        add.addActionListener(this);
        add.setBackground(Color.BLACK);
        add.setForeground(Color.WHITE);
        add(add);
        
        back = new JButton("Back");
        back.setBounds(450, 550, 150, 40);
        back.addActionListener(this);
        back.setBackground(Color.BLACK);
        back.setForeground(Color.WHITE);
        add(back);
        
        setSize(900, 700);
        setLocation(300, 50);
        setVisible(true);
    }
    
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == add) {
            String fname = tffname.getText();
            String salary = tfsalary.getText();
            String address = tfaddress.getText();
            String phone = tfphone.getText();
            String email = tfemail.getText();
            String education = tfeducation.getText();
            String designation = tfdesignation.getText();
            
            try {
                Conn conn = new Conn();
                String query = "update employee set fname = '"+fname+"', salary = '"+salary+"', address = '"+address+"', phone = '"+phone+"', email =  '"+email+"', education = '"+education+"', designation = '"+designation+"' where empId = '"+empId+"'";
                conn.s.executeUpdate(query);
                JOptionPane.showMessageDialog(null, "Details updated successfully");
                setVisible(false);
                new Home();
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            setVisible(false);
            new Home();
        }
    }

    public static void main(String[] args) {
        new UpdateEmployee("");
    }
}