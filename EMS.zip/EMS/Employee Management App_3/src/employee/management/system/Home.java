package employee.management.system;

//This class is used to create the GUI for the Home page of the employee management system.
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Home extends JFrame implements ActionListener {

	// Declaring the JButtons
	JButton view, add, update, remove, exit;

	Home() {

		// Setting the background color of the frame
		getContentPane().setBackground(Color.WHITE);
		setLayout(null);
		setTitle("Home - HCL Employee Management System");
		// Setting the icon Image
		ImageIcon favicon = new ImageIcon(ClassLoader.getSystemResource("icons/Hcl.jpg"));
		setIconImage(favicon.getImage());

		// Setting the background image
		ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/home.jpg"));
		Image i2 = i1.getImage().getScaledInstance(1120, 630, Image.SCALE_DEFAULT);
		ImageIcon i3 = new ImageIcon(i2);
		JLabel image = new JLabel(i3);
		image.setBounds(0, 0, 1120, 630);
		add(image);

		// Setting the heading
		JLabel heading = new JLabel("Employee Management System");
		heading.setBounds(620, 20, 400, 40);
		heading.setFont(new Font("TAHOMA", Font.BOLD, 25));
		image.add(heading);

		// Adding the JButtons
		add = new JButton("Add Employee");
		add.setBounds(650, 80, 150, 40);
		add.addActionListener(this);
		image.add(add);

		view = new JButton("View Employees");
		view.setBounds(820, 80, 150, 40);
		view.addActionListener(this);
		image.add(view);

		update = new JButton("Update Employee");
		update.setBounds(650, 140, 150, 40);
		update.addActionListener(this);
		image.add(update);

		remove = new JButton("Remove Employee");
		remove.setBounds(820, 140, 150, 40);
		remove.addActionListener(this);
		image.add(remove);

		exit = new JButton("Close");
		exit.setBounds(730, 200, 150, 40);
		exit.addActionListener(this);
		image.add(exit);

		// Setting the size, location and visibility of the frame
		setSize(1120, 630);
		setLocation(250, 100);
		setVisible(true);
	}

	// Method to close the frame
	public void close() {
		if (JOptionPane.showConfirmDialog(exit, "Confirm if you want to Exit", "Exit",
				JOptionPane.YES_NO_OPTION) == JOptionPane.YES_NO_OPTION) {
			System.exit(0);
		}
	}

	// Method to perform the action when the buttons are clicked

	public void actionPerformed(ActionEvent ae) {
		// If add button is clicked
		if (ae.getSource() == add) {
			// Shows the add employee window
			setVisible(true);
			new AddEmployee();
		}
		// If view button is clicked
		else if (ae.getSource() == view) {
			// Shows the view employee window
			setVisible(true);
			new ViewEmployee();
			// If update button is clicked
		} else if (ae.getSource() == update) {
			// Shows the view employee window
			setVisible(true);
			new ViewEmployee();
			// If remove button is clicked
		} else if (ae.getSource() == remove) {
			// Shows the remove employee window
			setVisible(true);
			new RemoveEmployee();
			// If exit button is clicked
		} else if (ae.getSource() == exit) {
			// Close the window
			setVisible(true);
			close();
		}
	}

	// This is the main method
	public static void main(String[] args) {
		// This is used to create an object of Home class
		new Home();
	}
}