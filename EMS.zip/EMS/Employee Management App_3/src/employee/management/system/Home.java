package employee.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Home extends JFrame implements ActionListener{

    JButton view, add, update, remove, exit;
    
    Home() {
    	
    	getContentPane().setBackground(Color.WHITE); 
        setLayout(null);
        setTitle("Home - HCL Employee Management System");
        ImageIcon favicon = new ImageIcon(ClassLoader.getSystemResource("icons/Hcl.jpg"));
        setIconImage(favicon.getImage());
        
        
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/home.jpg"));
        Image i2 = i1.getImage().getScaledInstance(1120, 630, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(0, 0, 1120, 630);
        add(image);
        
        JLabel heading = new JLabel("Employee Management System");
        heading.setBounds(620, 20, 400, 40);
        heading.setFont(new Font("TAHOMA", Font.BOLD, 25));
        image.add(heading);
        
        add = new JButton("Add Employee");
        add.setBounds(650, 80, 150, 40);
        add.addActionListener(this);
        image.add(add);
        
        view = new JButton("View Employees");
        view.setBounds(820, 80, 150, 40);
        view.addActionListener(this);
        image.add(view);
        
        update = new JButton("Update Employee");
        update.setBounds(650, 140, 150, 40);
        update.addActionListener(this);
        image.add(update);
        
        remove = new JButton("Remove Employee");
        remove.setBounds(820, 140, 150, 40);
        remove.addActionListener(this);
        image.add(remove);
       
        exit = new JButton("Close");
        exit.setBounds(730, 200, 150, 40);
        exit.addActionListener(this);
        image.add(exit);
        
        setSize(1120, 630);
        setLocation(250, 100);
        setVisible(true);
    }
    public void close() {   
    	if (JOptionPane.showConfirmDialog(exit, "Confirm if you want to Exit","Exit", JOptionPane.YES_NO_OPTION)==JOptionPane.YES_NO_OPTION)
    	{
    		System.exit(0);
    	}
//    	WindowEvent closeWin = new WindowEvent(this, WindowEvent.WINDOW_CLOSING);
//		Toolkit.getDefaultToolkit().getSystemEventQueue().postEvent(closeWin);
    }

    public void actionPerformed(ActionEvent ae) {
          if (ae.getSource() == add) {
              setVisible(true);
              new AddEmployee();
          } else if (ae.getSource() == view) {
              setVisible(true);
              new ViewEmployee();
          } else if (ae.getSource() == update) {
              setVisible(true);
              new ViewEmployee();
          } else if (ae.getSource()==remove){
              setVisible(true);
              new RemoveEmployee();
          }else if(ae.getSource()==exit){
              setVisible(true);
              close();
          }
      }
  
    public static void main(String[] args) {
        new Home();
    }
}