
package employee.management.system;

//importing required classes for establishing a connection
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

//class to establish a connection with a database
public class Conn {
	
	//declaring variables of type Connection and Statement
	Connection c;
	Statement s;
	
	//constructor to create a connection with the database
	public Conn() {
		try {
			//loading the driver
			Class.forName("com.mysql.cj.jdbc.Driver");
			//creating a connection with the database
			c = DriverManager.getConnection("jdbc:mysql:///employeemanagementsystem", "root", "Abhay@03#");
			//creating a statement
			s = c.createStatement();
		}
		//catching any exceptions
		catch (Exception e) {
			e.printStackTrace();
		}
	}

}