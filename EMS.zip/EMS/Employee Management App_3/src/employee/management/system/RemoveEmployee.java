package employee.management.system;


import javax.swing.*;
import java.awt.*;
import java.sql.*;
import java.awt.event.*;

	// extends JFrame class to use its properties and methods
	public class RemoveEmployee extends JFrame implements ActionListener {

	    // Choice class to create a drop-down list of Employees
	    Choice cEmpId;
	    JButton delete, back;

	    // Constructor to design the UI
	    RemoveEmployee() {
	        getContentPane().setBackground(Color.WHITE); // Set background color to white
	        setLayout(null); // Set layout as null
	        setTitle("HCL Employee Management System - Remove Employee"); // Set frame title
	        ImageIcon favicon = new ImageIcon(ClassLoader.getSystemResource("icons/Hcl.jpg")); // Load and set the icon image
	        setIconImage(favicon.getImage());

	        // Create Employee ID label
	        JLabel labelempId = new JLabel("Employee Id");
	        labelempId.setBounds(50, 50, 100, 30);
	        add(labelempId);

	        // Create Employee ID drop-down list
	        cEmpId = new Choice();
	        cEmpId.setBounds(200, 50, 150, 30);
	        add(cEmpId);

	        // Try-catch block to fetch the employees from the database
	        try {
	            Conn c = new Conn();
	            String query = "select * from employee";
	            ResultSet rs = c.s.executeQuery(query);
	            while (rs.next()) {
	                cEmpId.add(rs.getString("empId"));
	            }
	        } catch (Exception e) {
	            e.printStackTrace();
	        }

	        // Create Name label
	        JLabel labelname = new JLabel("Name");
	        labelname.setBounds(50, 100, 100, 30);
	        add(labelname);

	        // Create a name label to show employee's name
	        JLabel lblname = new JLabel();
	        lblname.setBounds(200, 100, 100, 30);
	        add(lblname);

	        // Create Phone label
	        JLabel labelphone = new JLabel("Phone");
	        labelphone.setBounds(50, 150, 100, 30);
	        add(labelphone);

	        // Create a phone label to show employee's phone number
	        JLabel lblphone = new JLabel();
	        lblphone.setBounds(200, 150, 100, 30);
	        add(lblphone);

	        // Create Email label
	        JLabel labelemail = new JLabel("Email");
	        labelemail.setBounds(50, 200, 100, 30);
	        add(labelemail);

	        // Create an email label to show employee's email address
	        JLabel lblemail = new JLabel();
	        lblemail.setBounds(200, 200, 100, 30);
	        add(lblemail);

	        // Try-catch block to fetch the employee's details from the database
	        try {
	            Conn c = new Conn();
	            String query = "select * from employee where empId = '" + cEmpId.getSelectedItem() + "'";
	            ResultSet rs = c.s.executeQuery(query);
	            while (rs.next()) {
	                lblname.setText(rs.getString("name"));
	                lblphone.setText(rs.getString("phone"));
	                lblemail.setText(rs.getString("email"));
	            }
	        } catch (Exception e) {
	            e.printStackTrace();
	        }

	        // Add item listener to the drop-down list to fetch details of the selected employee
	        cEmpId.addItemListener(new ItemListener() {
	            public void itemStateChanged(ItemEvent ie) {
	                try {
	                    Conn c = new Conn();
	                    String query = "select * from employee where empId = '" + cEmpId.getSelectedItem() + "'";
	                    ResultSet rs = c.s.executeQuery(query);
	                    while (rs.next()) {
	                        lblname.setText(rs.getString("name"));
	                        lblphone.setText(rs.getString("phone"));
	                        lblemail.setText(rs.getString("email"));
	                    }
	                } catch (Exception e) {
	                    e.printStackTrace();
	                }
	            }
	        });

	        // Create a delete button
	        delete = new JButton("Delete");
	        delete.setBounds(80, 300, 100, 30);
	        delete.setBackground(Color.BLACK);
	        delete.setForeground(Color.WHITE);
	        delete.addActionListener(this);
	        add(delete);

	        // Create a back button
	        back = new JButton("Back");
	        back.setBounds(220, 300, 100, 30);
	        back.setBackground(Color.BLACK);
	        back.setForeground(Color.WHITE);
	        back.addActionListener(this);
	        add(back);

	        // Load and set the delete icon
	        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/delete.png"));
	        Image i2 = i1.getImage().getScaledInstance(600, 400, Image.SCALE_DEFAULT);
	        ImageIcon i3 = new ImageIcon(i2);
	        JLabel image = new JLabel(i3);
	        image.setBounds(350, 0, 600, 400);
	        add(image);

	        // Set frame size, location and visibility
	        setSize(1000, 400);
	        setLocation(300, 150);
	        setVisible(true);
	    }

	    // Override actionPerformed method of ActionListener interface
	    public void actionPerformed(ActionEvent ae) {
	        // If delete button is clicked
	        if (ae.getSource() == delete) {
	            try {
	                Conn c = new Conn();
	                // Execute delete query to delete the selected employee details
	                String query = "delete from employee where empId = '" + cEmpId.getSelectedItem() + "'";
	                c.s.executeUpdate(query);
	                // Show success message
	                JOptionPane.showMessageDialog(null, "Employee Information Deleted Sucessfully");
	                setVisible(false);
	                new Home();
	            } catch (Exception e) {
	                e.printStackTrace();
	            }
	        }
	        // If back button is clicked
	        else {
	            setVisible(false);
	            new Home();
	        }
	    }

	    public static void main(String[] args) {
	        new RemoveEmployee();
	    }
}