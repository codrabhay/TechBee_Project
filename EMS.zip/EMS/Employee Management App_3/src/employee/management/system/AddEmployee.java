package employee.management.system;

import javax.swing.JFrame;
import javax.swing.*;

import com.toedter.calendar.JDateChooser;
import java.util.*;
import java.awt.*;
import java.awt.event.*;

//This class is used to add the details of Employee
public class AddEmployee extends JFrame implements ActionListener{
    
    //Generate random number
    Random ran = new Random();
    int number = ran.nextInt(999999); 
    
    //Declaring all text fields
    JTextField tfname, tffname, tfaddress, tfphone, tfaadhar, tfemail, tfsalary, tfdesignation;
    JDateChooser dcdob;
    JComboBox cbeducation;
    JLabel lblempId;
    JButton add, back;
    
    //Building constructor for AddEmployee class
    AddEmployee() {
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);
        setTitle("HCL Employee Management System - Add Employee");
        ImageIcon favicon = new ImageIcon(ClassLoader.getSystemResource("icons/Hcl.jpg"));
        setIconImage(favicon.getImage());
        
        //Creating Header Label
        JLabel heading = new JLabel("Add Employee Detail");
        heading.setBounds(320, 30, 500, 50);
        heading.setFont(new Font("SAN_SERIF", Font.BOLD, 25));
        add(heading);
        
        //Creating Label for Name
        JLabel labelname = new JLabel("Name");
        labelname.setBounds(50, 150, 150, 30);
        labelname.setFont(new Font("serif", Font.PLAIN, 20));
        add(labelname);
        
        //Creating Text Field for Name
        tfname = new JTextField();
        tfname.setBounds(200, 150, 150, 30);
        add(tfname);
        
        //Creating Label for Father's Name
        JLabel labelfname = new JLabel("Father's Name");
        labelfname.setBounds(400, 150, 150, 30);
        labelfname.setFont(new Font("serif", Font.PLAIN, 20));
        add(labelfname);
        
        //Creating Text Field for Father's Name
        tffname = new JTextField();
        tffname.setBounds(600, 150, 150, 30);
        add(tffname);
        
        //Creating Label for Date of Birth
        JLabel labeldob = new JLabel("Date of Birth");
        labeldob.setBounds(50, 200, 150, 30);
        labeldob.setFont(new Font("serif", Font.PLAIN, 20));
        add(labeldob);
        
        //Creating Date Chooser for Date of Birth
        dcdob = new JDateChooser();
        dcdob.setBounds(200, 200, 150, 30);
        add(dcdob);
        
        //Creating Label for Salary
        JLabel labelsalary = new JLabel("Salary");
        labelsalary.setBounds(400, 200, 150, 30);
        labelsalary.setFont(new Font("serif", Font.PLAIN, 20));
        add(labelsalary);
        
        //Creating Text Field for Salary
        tfsalary = new JTextField();
        tfsalary.setBounds(600, 200, 150, 30);
        add(tfsalary);
        
        //Creating Label for Address
        JLabel labeladdress = new JLabel("Address");
        labeladdress.setBounds(50, 250, 150, 30);
        labeladdress.setFont(new Font("serif", Font.PLAIN, 20));
        add(labeladdress);
        
        //Creating Text Field for Address
        tfaddress = new JTextField();
        tfaddress.setBounds(200, 250, 150, 30);
        add(tfaddress);
        
        //Creating Label for Phone
        JLabel labelphone = new JLabel("Phone");
        labelphone.setBounds(400, 250, 150, 30);
        labelphone.setFont(new Font("serif", Font.PLAIN, 20));
        add(labelphone);
        
        //Creating Text Field for Phone
        tfphone = new JTextField();
        tfphone.setBounds(600, 250, 150, 30);
        add(tfphone);
        
        //Creating Label for Email
        JLabel labelemail = new JLabel("Email");
        labelemail.setBounds(50, 300, 150, 30);
        labelemail.setFont(new Font("serif", Font.PLAIN, 20));
        add(labelemail);
        
        //Creating Text Field for Email
        tfemail = new JTextField();
        tfemail.setBounds(200, 300, 150, 30);
        add(tfemail);
        
        //Creating Label for Highest Education
        JLabel labeleducation = new JLabel("Higest Education");
        labeleducation.setBounds(400, 300, 150, 30);
        labeleducation.setFont(new Font("serif", Font.PLAIN, 20));
        add(labeleducation);
        
        //Creating Combo Box for Highest Education
        String courses[] = {"BBA", "BCA", "BA", "BSC", "B.COM", "BTech", "MBA", "MCA", "MA", "MTech", "MSC", "PHD"};
        cbeducation = new JComboBox(courses);
        cbeducation.setBackground(Color.WHITE);
        cbeducation.setBounds(600, 300, 150, 30);
        add(cbeducation);
        
        //Creating Label for Designation
        JLabel labeldesignation = new JLabel("Designation");
        labeldesignation.setBounds(50, 350, 150, 30);
        labeldesignation.setFont(new Font("serif", Font.PLAIN, 20));
        add(labeldesignation);
        
        //Creating Text Field for Designation
        tfdesignation = new JTextField();
        tfdesignation.setBounds(200, 350, 150, 30);
        add(tfdesignation);
        
        //Creating Label for Aadhar Number
        JLabel labelaadhar = new JLabel("Aadhar Number");
        labelaadhar.setBounds(400, 350, 150, 30);
        labelaadhar.setFont(new Font("serif", Font.PLAIN, 20));
        add(labelaadhar);
        
        //Creating Text Field for Aadhar Number
        tfaadhar = new JTextField();
        tfaadhar.setBounds(600, 350, 150, 30);
        add(tfaadhar);
        
        //Creating Label for Employee Id
        JLabel labelempId = new JLabel("Employee id");
        labelempId.setBounds(50, 400, 150, 30);
        labelempId.setFont(new Font("serif", Font.PLAIN, 20));
        add(labelempId);
        
        //Creating Label for showing Employee Id
        lblempId = new JLabel("" + number);
        lblempId.setBounds(200, 400, 150, 30);
        lblempId.setFont(new Font("serif", Font.PLAIN, 20));
        add(lblempId);
        
       // Adding the buttons
        add = new JButton("Add Details");
        add.setBounds(250, 550, 150, 40);
        add.addActionListener(this);
        add.setBackground(Color.BLACK);
        add.setForeground(Color.WHITE);
        add(add);
        
        back = new JButton("Back");
        back.setBounds(450, 550, 150, 40);
        back.addActionListener(this);
        back.setBackground(Color.BLACK);
        back.setForeground(Color.WHITE);
        add(back);
        
     // Setting the size and location of the frame and setting it to visible
        setSize(900, 700);
        setLocation(300, 50);
        setVisible(true);
    }
    
	// action performed to add employees into database
	public void actionPerformed(ActionEvent ae) {
		if (ae.getSource() == add) {

			// This line of code stores name entered in the text field in the variable name
			String name = tfname.getText();

			// This line of code stores father's name entered in the text field in the
			// variable fname
			String fname = tffname.getText();

			// This line of code stores date of birth entered in the text field in the
			// variable dob
			String dob = ((JTextField) dcdob.getDateEditor().getUiComponent()).getText();

			// This line of code stores salary entered in the text field in the variable
			// salary
			String salary = tfsalary.getText();

			// This line of code stores address entered in the text field in the variable
			// address
			String address = tfaddress.getText();

			// This line of code stores phone number entered in the text field in the
			// variable phone
			String phone = tfphone.getText();

			// This line of code stores email entered in the text field in the variable
			// email
			String email = tfemail.getText();

			// This line of code stores education selected in the combo box in the variable
			// education
			String education = (String) cbeducation.getSelectedItem();

			// This line of code stores designation entered in the text field in the
			// variable designation
			String designation = tfdesignation.getText();

			// This line of code stores aadhar number entered in the text field in the
			// variable aadhar
			String aadhar = tfaadhar.getText();

			// This line of code stores employee id entered in the text field in the
			// variable empId
			String empId = lblempId.getText();

			try {
				// This line of code establishes the connection with the database
				Conn conn = new Conn();
				// This line of code inserts the details into the employee table in the database
				String query = "insert into employee values('" + name + "', '" + fname + "', '" + dob + "', '" + salary
						+ "', '" + address + "', '" + phone + "', '" + email + "', '" + education + "', '" + designation
						+ "', '" + aadhar + "', '" + empId + "')";
				conn.s.executeUpdate(query);
				// This line of code displays a message when the details are successfully added
				JOptionPane.showMessageDialog(null, "Details added successfully");
				// This line of code sets the current window to invisible and calls the Home
				// class
				setVisible(false);
				new Home();
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else {
			// This line of code sets the current window to invisible and calls the Home
			// class
			setVisible(false);
			new Home();
		}
	}

    public static void main(String[] args) {
        new AddEmployee();
    }
}