package employee.management.system;

//this is Login class which helps to login into the employee management system
import java.awt.Color;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class Login extends JFrame implements ActionListener{
 
 // Declaring the necessary variables
 JTextField tfusername;
 JPasswordField tfPassword;

 Login() {
     getContentPane().setBackground(Color.WHITE);
     setLayout(null);
     setTitle("HCL Employee Management System - Login Employee");
     ImageIcon favicon = new ImageIcon(ClassLoader.getSystemResource("icons/Hcl.jpg"));
     setIconImage(favicon.getImage());
     
     // Declaring and Initializing the label for username
     JLabel lblusername = new JLabel("Username");
     lblusername.setBounds(40,20,100,30);
     add(lblusername);
     
     // Declaring and Initializing the textfield for username
     tfusername = new JTextField();
     tfusername.setBounds(150,20,150,30);
     add(tfusername);
     
     // Declaring and Initializing the label for password
     JLabel lblpassword = new JLabel("Password");
     lblpassword.setBounds(40,70,100,30);
     add(lblpassword);
     
     // Declaring and Initializing the textfield for password
     tfPassword = new JPasswordField();
     tfPassword.setBounds(150,70,150,30);
     add(tfPassword);
     
 	// Declaring and Initializing the button for login
 	JButton login = new JButton("LOGIN");
 	login.setBounds(150, 140, 150, 30);
 	login.setBackground(Color.black);
 	login.setForeground(Color.white);
 	login.addActionListener(this);
 	add(login);
 	
 	// Declaring and Initializing the image
 	ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/second.jpg"));
 	Image i2 = i1.getImage().getScaledInstance(200, 200, Image.SCALE_DEFAULT);
 	ImageIcon i3 = new ImageIcon(i2);
 	JLabel image = new JLabel(i3);
 	image.setBounds(350, 0, 200, 200); 
 	add(image);
     
     // Setting the size and location of the frame and setting it to visible
     setSize(600,300);
     setLocation(450,200);
     setVisible(true);
     
 }
 // action performed to check for the valid credentials
//This method is triggered when an action is performed
public void actionPerformed(ActionEvent ae) {
	try {
		// Getting the username and password from textfields
		String username = tfusername.getText();
		String password = tfPassword.getText();
		
		// Instantiating the Conn class to get the connection
		Conn c = new Conn();
		// creating a query to check if the entered credentials are valid
		String query = "select * from login where username = '"+username+"' and password = '"+password+"'";
		
		// Executing the query
		ResultSet rs = c.s.executeQuery(query);
		// Checking if the credentials are valid
		if(rs.next()) {
			// if credentials are valid, then hide the login window
			setVisible(false);
			// open the next class
			new Home();
			
		}else {
			// if credentials are invalid, show a message
			JOptionPane.showMessageDialog(null, "Invalid username or password");
		}
	}catch(Exception e) {
		e.printStackTrace();
	}
}

 public static void main(String[] args) {
	 //Instantiate a new Login object
	 new Login();
 }
}
