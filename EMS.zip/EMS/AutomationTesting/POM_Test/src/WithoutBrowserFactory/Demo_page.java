package WithoutBrowserFactory;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class Demo_page {
	WebDriver driver;


	//This is the locator for the first name field
	By fname = By.name("FirstName");
	//This is the locator for the last name field
	By lname = By.name("LastName");
	//This is the locator for the email field
	By email = By.name("Email");
	//This is the locator for the password field
	By pass = By.name("Password");
	//This is the locator for the confirm password field
	By conpass = By.name("ConfirmPassword");
	//This is the locator for the register button
	By Register = By.name("register-button");
	//This is the locator for the search product field
	By search_p = By.name("q");
	//This is the locator for the search button
	By searchbtn = By.xpath("/html/body/div[6]/div[1]/div[2]/div[2]/form/button");
	//This is the locator for the image of the product
	By image = By.xpath("/html/body/div[6]/div[3]/div/div[2]/div/div[2]/div[3]/div/div[2]/div/div/div/div/div[2]/h2/a");
	//This is the locator for the Add to Cart button
	By AddToCart = By.xpath("/html/body/div[6]/div[3]/div/div[2]/div/div/form/div[2]/div[1]/div[2]/div[8]/div[2]/button");
	//This is the locator for the Shopping Cart link
	By ShopCart = By.id("topcartlink");
	//This is the locator for the Terms & Conditions agree checkbox
	By agreebox = By.xpath("/html/body/div[6]/div[3]/div/div/div/div[2]/div/form/div[3]/div[2]/div[3]/label");
	//This is the locator for the Checkout button
	By CheckBox = By.id("checkout");
	//This is the locator for the Checkout as Guest button
	By CheckGuest = By.xpath("/html/body/div[6]/div[3]/div/div/div/div[2]/div[1]/div[1]/div[3]/button[1]");
	//This is the locator for the first name field in the Billing & Shipping Details form
	By Fname = By.id("BillingNewAddress_FirstName");
	//This is the locator for the last name field in the Billing & Shipping Details form
	By Lname = By.id("BillingNewAddress_LastName");
	//This is the locator for the email field in the Billing & Shipping Details form
	By email1 = By.id("BillingNewAddress_Email");
	//This is the locator for the city field in the Billing & Shipping Details form
	By cityname = By.name("BillingNewAddress.City");
	//This is the locator for the address field in the Billing & Shipping Details form
	By Address = By.name("BillingNewAddress.Address1");
	//This is the locator for the zip code field in the Billing & Shipping Details form
	By zip = By.name("BillingNewAddress.ZipPostalCode");
	//This is the locator for the phone number field in the Billing & Shipping Details form
	By Phonenumber = By.name("BillingNewAddress.PhoneNumber");
	//This is the locator for the Continue button in the Billing & Shipping Details form
	By cont = By.name("save");
	//This is the locator for the Continue button in the Shipping Method form
	By contt = By.xpath("/html/body/div[6]/div[3]/div/div/div/div[2]/ol/li[3]/div[2]/form/div[2]/button");
	//This is the locator for the Continue button in the Payment Method form
	By conttt = By.xpath("/html/body/div[6]/div[3]/div/div/div/div[2]/ol/li[4]/div[2]/div/button");
	//This is the locator for the Continue button in the Payment Information form
	By contttt = By.xpath("/html/body/div[6]/div[3]/div/div/div/div[2]/ol/li[5]/div[2]/div/button");
	
	//This is the locator for the Continue button in the Payment Method form
	By confirm = By.xpath("/html/body/div[6]/div[3]/div/div/div/div[2]/ol/li[6]/div[2]/div[2]/button");
	//This is the locator for the Continue button in the Payment Information form
	By strong = By.xpath("/html/body/div[6]/div[3]/div/div/div/div[2]/div/div[1]/strong");
	

	//This method is used to set firstname
		public void setfname(String Firstname) {
			driver.findElement(fname).sendKeys(Firstname);
		}

	//This method is used to set the lastname
		public void setlname(String Lastname) {
			driver.findElement(lname).sendKeys(Lastname);
		}

	//This method is used to set the email
		public void email(String Email) {
			driver.findElement(email).sendKeys(Email);
		}

	//This method is used to set the password
		public void setpass(String password) {
			driver.findElement(pass).sendKeys(password);
		}

	//This method is used to set the confirm password
		public void setconpass(String confirmpass) {
			driver.findElement(conpass).sendKeys(confirmpass);
		}

	//This method is used to click the register button
		public void register() {
			driver.findElement(Register).click();
		}

	//This method is used to set the product name to search
		public void search(String products) {
			driver.findElement(search_p).sendKeys(products);
		}

	//This method is used to click the search button
		public void sbutton() {
			driver.findElement(searchbtn).click();
		}

	//This method is used to click the product image
		public void image_product() {
			driver.findElement(image).click();
		}

	//This method is used to add the product to the cart
		public void addtocart() {
			driver.findElement(AddToCart).click();
		}

	//This method is used to click the shopping cart
		public void shopcart() {
			driver.findElement(ShopCart).click();
		}

	//This method is used to check the agree box
		public void agreecheckbox() {
			driver.findElement(agreebox).click();
		}

	//This method is used to click the checkout button
		public void checkout() {
			driver.findElement(CheckBox).click();
		}

	 //This method is used to check the guest button
		public void Check_Guest() {
			driver.findElement(CheckGuest).click();
		}

	//This method is used to set the first name
		public void firstname(String firstname) {
			driver.findElement(Fname).sendKeys(firstname);
		}

	//This method is used to set the last name
		public void lastname(String lastname) {
			driver.findElement(Lname).sendKeys(lastname);
		}

	//This method is used to set the email address
		public void Email(String Email) {
			driver.findElement(email1).sendKeys(Email);
		}

	//This method is used to set the city name
		public void City(String city) {
			driver.findElement(cityname).sendKeys(city);
		}

	//This method is used to set the address
		public void address(String address) {
			driver.findElement(Address).sendKeys(address);
		}

	//This method is used to set the zip/postal code
		public void zip_postalcode(String zip_postalcode) {
			driver.findElement(zip).sendKeys(zip_postalcode);
		}

	//This method is used to set the phone number
		public void phone_number(String phone_number) {
			driver.findElement(Phonenumber).sendKeys(phone_number);
		}

	//This method is used to click the continue button
		public void conti() {
			driver.findElement(cont).click();
		}

	//This method is used to click the continue button
		public void contin() {
			driver.findElement(contt).click();
		}

	//This method is used to click the continue button
		public void continn() {
			driver.findElement(conttt).click();
		}

	//This method is used to click the continue button
		public void continnn() {
			driver.findElement(contttt).click();
		}
		//This method is used to click the continue button
		public void confirm() {
			driver.findElement(confirm).click();
		}
		//This method is used to click the continue button
		public String strong() {
			String StrongTxt = driver.findElement(strong).getText();
			return StrongTxt;
		}

	//This is the constructor of the class
		public Demo_page(WebDriver driver) {
			this.driver = driver;
		}
}
