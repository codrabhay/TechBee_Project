package WithoutBrowserFactory;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

public class Test_Demo {

	WebDriver driver;

	@Test
	public void setUp() {

		//System.setProperty is used to set the path of the chromedriver
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\abhay.k\\Downloads\\DriverAndJar\\chromedriver_win32\\chromedriver.exe");

		//Creating an object of ChromeDriver
		driver = new ChromeDriver();

		//Setting the baseurl
		String baseUrl = "https://demo.nopcommerce.com/register?returnUrl=%2F";

		//Opening the URL in browser
		driver.get(baseUrl);

		//Maximizing the window
		driver.manage().window().maximize();

		//Setting the timeout
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		//Creating an object of Demo_page class
		Demo_page obj = new Demo_page(driver);

		//Entering the first name
		obj.setfname("Mahira");

		//Entering the last name
		obj.setlname("Singh");

		//Entering the email address
		obj.email("xiwaliy974@usharer.com");

		//Entering the password
		obj.setpass("t.y.p.e@1233");

		//Confirming the password
		obj.setconpass("t.y.p.e@1233"); 

		//Clicking on the register button
		obj.register();

		//Printing the message
		System.out.println("Your registration completed");


		//Get the title of the page and verify whether it is nopCommerce demo store
		String titleTxt = driver.getTitle();
		Assert.assertTrue(titleTxt.contains("nopCommerce demo store"));

		System.out.println(titleTxt);

		//Search the product Apple MacBook Pro 13-inch
		obj.search("Apple MacBook Pro 13-inch");

		//Click on the search button
		obj.sbutton();

		//Scroll down the page
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("window.scrollBy(0,600)", "");

		//Click on the product image
		obj.image_product();

		//Scroll down the page
		JavascriptExecutor jse1 = (JavascriptExecutor) driver;
		jse1.executeScript("window.scrollBy(0,300)", "");

		//Click on Add to cart
		obj.addtocart();

		//Scroll up the page
		JavascriptExecutor jse2 = (JavascriptExecutor) driver;
		jse2.executeScript("window.scrollBy(0,-300)", "");

		//Click on Shopping cart
		obj.shopcart();
		System.out.println("product added to your shopping cart");
		          
		//Scroll down the page
		JavascriptExecutor jse3 = (JavascriptExecutor) driver;
		jse3.executeScript("window.scrollBy(0,400)", "");

		//Select the checkbox
		obj.agreecheckbox();

		//Click on checkout
		obj.checkout();
		System.out.println("Checked out successfully");
 

		//Check Guest and enter the firstname
		obj.Check_Guest();
		obj.firstname("Samaiyra");

		//Enter the lastname
		obj.lastname("kashyap");

		//Enter the Email
		obj.Email("xiwaliy974@usharer.com");

		//Select Country from drop down
		Select dropdown = new Select(driver.findElement(By.id("BillingNewAddress_CountryId")));
		dropdown.selectByVisibleText("India");
		dropdown.selectByIndex(100);

		//Enter City
		obj.City("vishakhapatnam");

		//Enter address
		obj.address("Singapore colony");

		//Enter zip/postal code
		obj.zip_postalcode("123456");

		//Enter Phone number
		obj.phone_number("123456789");

		//click on continue button
		obj.conti();
		obj.contin();
		obj.continn();
		obj.continnn();
		obj.confirm();
//		obj.strong();
		//Print order confirmation
		Assert.assertEquals("Your order has been successfully processed!",obj.strong());
		System.out.println(obj.strong());

//		driver.quit();
	}

}
