package withBrowserFactory;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

public class Test_Demo_new {
	WebDriver driver;

	@Test
	public void Order_product() {

		//This code is to launch the chrome driver and open the URL in given.
		WebDriver driver = Browser_Factory.stratBrowser("chrome", "https://demo.nopcommerce.com/register?returnUrl=%2F");

		//Creating an object of Demopage_New to call the methods of the class on the page.
		Demopage_New dn = PageFactory.initElements(driver, Demopage_New.class);

		//Calling the method Demo_page of class Demopage_New on the page with the given values.
		dn.Demo_page("Mahira", "Singh", "xiwaliy974@usharer.com", "t.y.p.e@1233", "t.y.p.e@1233",
						"Apple MacBook Pro 13-inch", "Samaiyra", "Kashayap", "xiwaliy974@usharer.com", "Vishakhapatanam",
						"singapore colony", "123456", "1234567890");

		//The above code is used to launch the chrome driver, open the URL and then call the Demo_page method of the Demopage_New class by passing the given values.
		driver.close();
	}
}