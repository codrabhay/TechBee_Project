package withBrowserFactory;


import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.opera.OperaDriver;



public class Browser_Factory {
	//This is a method to start a browser by taking two arguments: browser name and url.
	static WebDriver driver;

	public static WebDriver stratBrowser(String browser, String url) {
	    // This if statement checks the browser name, and sets the property accordingly. 
			if (browser.equalsIgnoreCase("chrome")) {
				System.setProperty("webdriver.chrome.driver",
						"C:\\Users\\abhay.k\\Downloads\\DriverAndJar\\chromedriver_win32\\chromedriver.exe");
				driver = new ChromeDriver();
			} else if (browser.equalsIgnoreCase("edge")) {
				System.setProperty("webdriver.edge.driver",
						"C:\\Users\\abhay.k\\Downloads\\DriverAndJar\\edgedriver_win64\\msedgedriver.exe");
				driver = new EdgeDriver();
			} else if (browser.equalsIgnoreCase("opera")) {
				System.setProperty("webdriver.opera.driver",
						"C:\\Users\\abhay.k\\Downloads\\operadriver_win64\\operadriver_win64\\operadriver.exe");
				driver = new OperaDriver();
			}
	    // This line helps the driver get to the specified URL. 
	         driver.get(url);
	    // This line helps the driver wait for a specified time before performing any operations.
	         driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	    // This line helps the driver to maximize the window of the browser. 
	         driver.manage().window().maximize();
	    // This line returns the driver object. 
	         return driver;
	
     }
}