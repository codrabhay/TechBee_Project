package withBrowserFactory;


import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.opera.OperaDriver;



public class Browser_Factory {
     static WebDriver driver;

     public static WebDriver stratBrowser(String browser, String url) {
 		if (browser.equalsIgnoreCase("chrome")) {
			System.setProperty("webdriver.chrome.driver",
					"C:\\Users\\abhay.k\\Downloads\\DriverAndJar\\chromedriver_win32\\chromedriver.exe");
			driver = new ChromeDriver();
		} else if (browser.equalsIgnoreCase("edge")) {
			System.setProperty("webdriver.edge.driver",
					"C:\\Users\\abhay.k\\Downloads\\DriverAndJar\\edgedriver_win64\\msedgedriver.exe");
			driver = new EdgeDriver();
		} else if (browser.equalsIgnoreCase("opera")) {
			System.setProperty("webdriver.opera.driver",
					"C:\\Users\\abhay.k\\Downloads\\operadriver_win64\\operadriver_win64\\operadriver.exe");
			driver = new OperaDriver();
		}

         driver.get(url);
         driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
         driver.manage().window().maximize();
         return driver;
     }
}