/**
/*
This code is used to signup in Swag Labs for different browsers using TestNG by running the testng.xml as TestNG Suite file in the root directory of POM_Test Project folder.
The different browsers which are used are Chrome, Edge and Opera.
The steps performed in this program are:
1. Set the system property for the respective browsers
2. Open the saucedemo.com website
3. Maximize the window
4. Add an implicit wait
5. Print the page title
6. Enter username in the username field
7. Enter password in the password field
8. Click the login button
9. Quit the browser 
*/

package crossBrowser;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.opera.OperaDriver;
import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class CrossBrowserSignUpOnSwagLabs {
	WebDriver driver;

	@Test
	@Parameters("browser")
	public void verifyPageTitle(String browserName) {
		
		// Check for the browser name
		if (browserName.equalsIgnoreCase("chrome")) {
			
			// Set the path for the Chrome driver
			System.setProperty("webdriver.chrome.driver",
					"C:\\Users\\abhay.k\\Downloads\\DriverAndJar\\chromedriver_win32\\chromedriver.exe");
			
			// Create an object of Chrome driver
			driver = new ChromeDriver();
		} 
		else if (browserName.equalsIgnoreCase("edge")) {
			
			// Set the path for the Edge driver
			System.setProperty("webdriver.edge.driver",
					"C:\\Users\\abhay.k\\Downloads\\DriverAndJar\\edgedriver_win64\\msedgedriver.exe");
			
			// Create an object of Edge driver
			driver = new EdgeDriver();
		}
		else if (browserName.equalsIgnoreCase("opera")) {
			
			// Set the path for the Opera driver
			System.setProperty("webdriver.opera.driver",
					"C:\\Users\\abhay.k\\Downloads\\operadriver_win64\\operadriver_win64\\operadriver.exe");
			
			// Create an object of Opera driver
			driver = new OperaDriver();
		}
		
		// Open the website
		driver.get("https://www.saucedemo.com");

		// Maximize the browser window
		driver.manage().window().maximize();
		// Set the wait time
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		// Print the title of the website
		
		Assert.assertEquals("Swag Labs",driver.getTitle());
		
		System.out.println(driver.getTitle());

		// Sign up on the website
		
		driver.findElement(By.id("user-name")).sendKeys("standard_user");
		driver.findElement(By.id("password")).sendKeys("secret_sauce");
		driver.findElement(By.id("login-button")).click();

		
		// Close the browser window
//		driver.quit();
	}
}