
//This program is to read data from excel sheet and perform login operation in LetsKodeIt website
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
//import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class ExcelExample { 
	WebDriver driver; 
	
//This test method is to enter email and password from excel sheet and perform login
	@Test(dataProvider = "testdata") 
	public void setupClass(String email, String password) throws InterruptedException {
		//Set the path for the chrome driver
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\abhay.k\\Downloads\\DriverAndJar\\chromedriver_win32\\chromedriver.exe");
		//Initialize the chrome driver
		 driver = new ChromeDriver();
		//Open the login page of letskodeit
		driver.get("https://courses.letskodeit.com/login");
		//Maximize the window
		driver.manage().window().maximize();
		//Set implicit wait
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

//This will enter email from excel sheet
		driver.findElement(By.name("email")).sendKeys(email);
//This will enter password from excel sheet
		driver.findElement(By.name("password")).sendKeys(password);
		driver.findElement(By.xpath("/html/body/div[1]/div[2]/div/div/div/div/form/div[4]/div[1]/input")).click();

	}

//This data Provider method is to read data from excel sheet
	@DataProvider(name = "testdata")
	public Object[][] testDataExample() {

//This will read data from excel sheet
		ReadExcelFile configuration = new ReadExcelFile(
				"C:\Users\abhay.k\OneDrive - HCL Technologies Ltd\Desktop\EMS\AutomationTesting\POM_Test\src\data_Driven\\letskodeit_2.xlsx");
		
		int rows = configuration.getRowCount(0);
		Object[][] signin = new Object[rows][2];

//This will store data in object
		for (int i = 0; i < rows; i++) {
			signin[i][0] = configuration.getData(0, i, 0);
			signin[i][1] = configuration.getData(0, i, 1);

		}
		return signin;
	}
}