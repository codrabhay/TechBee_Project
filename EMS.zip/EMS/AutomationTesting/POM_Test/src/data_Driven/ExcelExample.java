package data_Driven;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
//import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class ExcelExample {
	WebDriver driver;

	@Test(dataProvider = "testdata")
	public void setupClass(String email, String password) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\abhay.k\\Downloads\\DriverAndJar\\chromedriver_win32\\chromedriver.exe");
		 driver = new ChromeDriver();
		driver.get("https://courses.letskodeit.com/login");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		driver.findElement(By.name("email")).sendKeys(email);
		driver.findElement(By.name("password")).sendKeys(password);
		driver.findElement(By.xpath("/html/body/div[1]/div[2]/div/div/div/div/form/div[4]/div[1]/input")).click();

	}

	@DataProvider(name = "testdata")
	public Object[][] testDataExample() {

		ReadExcelFile configuration = new ReadExcelFile(
				"C:\\Users\\abhay.k\\OneDrive - HCL Technologies Ltd\\Documents\\letskodeit_2.xlsx");
		
		int rows = configuration.getRowCount(0);
		Object[][] signin = new Object[rows][2];

		for (int i = 0; i < rows; i++) {
			signin[i][0] = configuration.getData(0, i, 0);
			signin[i][1] = configuration.getData(0, i, 1);

		}
		return signin;
	}
}
