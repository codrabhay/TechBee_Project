package data_Driven;

import java.io.File;
import java.io.FileInputStream;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
//This class is used to read the Data from Excel file using Apache POI
public class ReadExcelFile {
	XSSFWorkbook work_book; //Creating the workbook object
	XSSFSheet sheet; //Creating the sheet object

	
	//Creating a Constructor to read the Excel file
	public ReadExcelFile(String excelfilePath) {
		try {
			File s = new File(excelfilePath); //Creating the file object
			FileInputStream stream = new FileInputStream(s); //Creating the FileInputStream object
			work_book = new XSSFWorkbook(stream); //Creating the workbook object with file path
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}


	//This method is used to get the Data from Excel file
	public String getData(int sheetnumber, int row, int column) {
		sheet = work_book.getSheetAt(sheetnumber); //Getting the particular sheet from the workbook
		String data = sheet.getRow(row).getCell(column).getStringCellValue(); //Getting the data from the cell
		return data;
	}


	//This method is used to get the total row count of particular sheet
	public int getRowCount(int sheetIndex) {
		int row = work_book.getSheetAt(sheetIndex).getLastRowNum(); //Getting the last row number
		row = row + 1;
		return row;
	}

}